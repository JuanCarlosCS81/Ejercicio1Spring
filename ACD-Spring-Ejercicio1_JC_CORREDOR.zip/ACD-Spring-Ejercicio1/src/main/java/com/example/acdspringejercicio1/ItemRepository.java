package com.example.acdspringejercicio1;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource(collectionResourceRel = "item", path = "item")
public interface ItemRepository extends MongoRepository<Item,String> {
    public List<Item> findItemByTipo(String tipo);
    public Item findItemByNombre(String nombre);
}
