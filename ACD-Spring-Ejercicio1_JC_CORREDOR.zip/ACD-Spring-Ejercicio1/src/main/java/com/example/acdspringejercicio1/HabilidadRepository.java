package com.example.acdspringejercicio1;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource(collectionResourceRel = "habilidad", path = "habilidad")
public interface HabilidadRepository extends MongoRepository<Habilidad,String> {
    public Habilidad findHabilidadByNombre(String nombre);
    public List<Habilidad> findAllByTipo(String tipo);
}
