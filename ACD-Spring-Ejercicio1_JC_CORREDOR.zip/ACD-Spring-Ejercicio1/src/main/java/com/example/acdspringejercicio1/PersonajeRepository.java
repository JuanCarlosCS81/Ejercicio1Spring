package com.example.acdspringejercicio1;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource(collectionResourceRel = "personaje", path = "personaje")
public interface PersonajeRepository extends MongoRepository<Personaje,String> {
    public Personaje findPersonajeByClase(String nombre);
    public Personaje findPersonajeByNombre(String nombre);

}
