package com.example.acdspringejercicio1;

import org.springframework.data.annotation.Id;

public class Item {
    @Id
    public String id;
    //Atributos
    private String nombre;
    private int vida;
    private String tipo;

    //Metodos

    //Constructor por defecto
    public Item()
    {
        nombre = "ninguno";
        vida = 0;
        tipo = "ninguno";
    }

    //Constructor sobrecargado
    public Item(String nombre, int vida, String tipo)
    {
        this.nombre = nombre;
        this.vida = vida;
        this.tipo = tipo;
    }

    //Constructor de copia
    public Item(com.example.acdspringejercicio1.Item item)
    {
        this.nombre = item.nombre;
        this.vida = item.vida;
        this.tipo = item.tipo;
    }

    //gets y sets

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    //Metodo comparar

    public boolean esIgual(com.example.acdspringejercicio1.Item item)
    {
        boolean salida = false;

        if(this.nombre.equals(item.nombre))
        {
            salida = true;
        }

        return salida;
    }

    @Override
    public boolean equals(Object item_entrada)
    {
        boolean salida = false;

        com.example.acdspringejercicio1.Item item = (com.example.acdspringejercicio1.Item) item_entrada;
        if(this.nombre.equals(item.nombre))
        {
            salida = true;
        }

        return salida;
    }



    //Metodo para mostrar
    public void visualizarBasico()
    {
        System.out.println("---------------------------");
        System.out.println("Nombre: "+ nombre);
        System.out.println("Vida: "+vida);
        System.out.println("Tipo: "+tipo);
        System.out.println("---------------------------");
    }


    public void visualizar()
    {
        System.out.println("---------------------------");
        System.out.println("Nombre: "+ nombre);
        System.out.println("Vida: "+vida);
        System.out.println("Tipo: "+tipo);
        System.out.println("---------------------------");
    }




    public String toString()
    {
        String cad;

        cad = this.nombre+";"+this.vida+";"+this.tipo+";";

        return cad;
    }
}

