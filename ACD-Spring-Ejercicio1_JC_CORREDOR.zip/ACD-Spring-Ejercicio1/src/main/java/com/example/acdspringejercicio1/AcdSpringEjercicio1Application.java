package com.example.acdspringejercicio1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcdSpringEjercicio1Application implements CommandLineRunner {
    //Arrays de habilidades
    private Habilidad[] habilidadesGuerrero = new Habilidad[5];
    private Habilidad[] habilidadesMago = new Habilidad[5];

    //arrays de items
    private Item[] itemsGuerrero = new Item[5];
    private Item[] itemsMago = new Item[5];

    //creamos los 3 repositorios(Personaje,Habilidad,Item)
    @Autowired
    private PersonajeRepository repositoryP;
    @Autowired
    private HabilidadRepository repositoryH;
    @Autowired
    private ItemRepository repositoryI;

    public static void main(String[] args) {
        SpringApplication.run(AcdSpringEjercicio1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        //borrar datos de items
        repositoryI.deleteAll();

        //guardar items
        repositoryI.save(new Item("Escudo",100,"Armadura-pesada"));
        repositoryI.save(new Item("Peto",100,"Armadura-pesada"));
        repositoryI.save(new Item("Baston",100,"Armadura-tela"));
        repositoryI.save(new Item("Tunica",100,"Armadura-tela"));

        //buscar todos los items
        for(Item item: repositoryI.findAll()){
            item.visualizar();
        }

        //buscar item por tipo
        int contadorItemGuerrero = 0;
        System.out.println("Items tipo pesado para guerrero");
        System.out.println(repositoryI.findItemByTipo("Armadura-pesada"));
        System.out.println("-----------------");
        //metemos items guerrero en array para usar en constructor de Personaje

        for(Item itemGuerrero: repositoryI.findItemByTipo("Armadura-pesada")){
            itemsGuerrero[contadorItemGuerrero] = itemGuerrero;
            contadorItemGuerrero++;
        }

        //buscar item por tipo
        int contadorItemMago = 0;
        System.out.println("Items tipo tela para magos");
        System.out.println(repositoryI.findItemByTipo("Armadura-tela"));
        System.out.println("-----------------");
        //metemos items mago en array para usar en constructor de Personaje
        for(Item itemMago: repositoryI.findItemByTipo("Armadura-tela")){
            itemsMago[contadorItemMago] = itemMago;
            contadorItemMago++;
        }

        //buscar item por nombre
        System.out.println(repositoryI.findItemByNombre("Escudo"));


        //borrar datos habilidades
        repositoryH.deleteAll();

        //guardar datos habilidades
        repositoryH.save(new Habilidad("Ataque cortante",20,5,"Espada"));
        repositoryH.save(new Habilidad("Ataque aereo",18,3,"Espada"));
        repositoryH.save(new Habilidad("Ataque carga",25,7,"Espada"));
        repositoryH.save(new Habilidad("Lanza de agua",35,10,"Magia"));
        repositoryH.save(new Habilidad("Dragon de fuego",40,12,"Magia"));
        repositoryH.save(new Habilidad("Muro de tierra",33,9,"Magia"));

        //buscar todas las habilidades
        for(Habilidad habilidad : repositoryH.findAll()){
            habilidad.visualizar();
            System.out.println("--------------------");
        }

        //buscar habilidades por tipo
        int contadorHabilidadGuerrero = 0;
        System.out.println("Habilidades tipo espada");
        System.out.println(repositoryH.findAllByTipo("Espada"));
        System.out.println("--------------------------");

        //metemos en array habilidades todas las del tipo guerrero para usar en constructor de crear Personaje
        for(Habilidad habilidadGuerrero : repositoryH.findAllByTipo("Espada") ){
            habilidadesGuerrero[contadorHabilidadGuerrero] = habilidadGuerrero;
            contadorHabilidadGuerrero++;
        }

        //buscar habilidades por tipo
        int contadorhabilidadMago = 0;
        System.out.println("Habilidades de magia");
        System.out.println(repositoryH.findAllByTipo("Magia"));
        System.out.println("--------------------------");

        //metemos en array habilidades todas las del tipo mago para usar en constructor de crear Personaje
        for(Habilidad habilidadMago : repositoryH.findAllByTipo("Magia") ){
            habilidadesMago[contadorhabilidadMago] = habilidadMago;
            contadorhabilidadMago++;
        }

        //buscar habilidades por nombre
        System.out.println(repositoryH.findHabilidadByNombre("Lanza de agua"));

        //borrar datos personajes
        repositoryP.deleteAll();

        //guardar datos Personaje
        repositoryP.save(new Personaje("Juan Carlos","Guerrero",100,100,100,100,100,habilidadesGuerrero,itemsGuerrero,false,false));
        repositoryP.save(new Personaje("Eva","Maga",100,100,100,100,100,habilidadesMago,itemsMago,false,false));
        System.out.println("------------------------------");
        //buscar todos los personajes con findAll()
        System.out.println("Buscar todos los personajes");
        for(Personaje personaje : repositoryP.findAll()){
            personaje.visualizar();
            System.out.println("------------------------------");
        }
        //buscar personaje por nombre
        System.out.println("Buscar personajes por nombre");
        repositoryP.findPersonajeByNombre("Eva").visualizar();
        System.out.println("----------------------");
        //buscar Personaje por clase
        System.out.println("Buscar personaje por clase");
        repositoryP.findPersonajeByClase("Guerrero").visualizar();
        System.out.println("----------------------");
    }
}
