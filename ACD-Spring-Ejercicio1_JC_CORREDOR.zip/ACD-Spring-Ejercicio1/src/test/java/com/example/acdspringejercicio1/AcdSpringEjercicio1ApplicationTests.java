package com.example.acdspringejercicio1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcdSpringEjercicio1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
